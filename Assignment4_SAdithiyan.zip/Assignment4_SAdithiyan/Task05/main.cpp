#include <iomanip>
#include <iostream>
#include <string>
class Cart { std::string items[10];double prices[10]{};int n=0;double discount=0; public:
    Cart& add(const std::string& item,double price){if(n<10){items[n]=item;prices[n]=price;++n;}return *this;}
    Cart& setDiscount(double discount){this->discount=discount;return *this;}
    double total()const{double t=0;for(int i=0;i<n;++i)t+=prices[i];return t*(100-discount)/100;}
};
int main(){Cart c;c.add("Rice",60).add("Dal",120).setDiscount(10);Cart* p=&c;p->add("Oil",180);std::cout<<std::fixed<<std::setprecision(2)<<p->total()<<'\n';Cart direct;direct.add("Book",100);Cart& ref=direct;Cart* heap=new Cart;heap->add("Tea",50);std::cout<<direct.total()<<' '<<ref.total()<<' '<<heap->total()<<'\n';delete heap;Cart a,b,d;a.add("A",20);b.add("B",90);d.add("C",45);Cart* carts[]={&a,&b,&d};Cart* best=carts[0];for(Cart** it=carts;it!=carts+3;++it)if((*it)->total()>best->total())best=*it;std::cout<<"Highest="<<best->total()<<'\n';}
