#include <iostream>
#include <string>
struct Address { std::string city; int pin; Address(std::string c,int p):city(std::move(c)),pin(p){std::cout<<"Address+ ";} ~Address(){std::cout<<"Address- ";} std::string str()const{return city+"-"+std::to_string(pin);} };
struct Person { std::string name; int age; Address address; Person(std::string n,int a,std::string c,int p):name(std::move(n)),age(a),address(std::move(c),p){std::cout<<"Person+ ";} virtual ~Person(){std::cout<<"Person- ";} };
struct Course { std::string title; Course(std::string t):title(std::move(t)){std::cout<<"Course+ ";} ~Course(){std::cout<<"Course- ";} };
struct Student : virtual Person { long long regNo; Course course; Student(std::string n,int a,long long r,std::string c,int p,std::string co):Person(std::move(n),a,std::move(c),p),regNo(r),course(std::move(co)){std::cout<<"Student+ ";} ~Student()override{std::cout<<"Student- ";} };
struct Staff : virtual Person { std::string department; Staff(std::string n,int a,std::string c,int p,std::string d):Person(std::move(n),a,std::move(c),p),department(std::move(d)){std::cout<<"Staff+ ";} ~Staff()override{std::cout<<"Staff- ";} };
struct TeachingAssistant : Student, Staff { TeachingAssistant(std::string n,int a,long long r,std::string c,int p,std::string co,std::string d):Person(n,a,c,p),Student(n,a,r,c,p,co),Staff(n,a,c,p,d){std::cout<<"TA+ ";} ~TeachingAssistant()override{std::cout<<"TA- ";} };
int main(){std::cout<<"Student trace: ";{Student s("Kavya",19,192311001,"Salem",636001,"OOP");std::cout<<"\n"<<s.regNo<<" "<<s.name<<" ("<<s.age<<") "<<s.address.str()<<"\n";}std::cout<<"\nTA trace: ";{TeachingAssistant t("Arun",20,192311002,"Chennai",600001,"C++","CSE");}std::cout<<"\n";}
