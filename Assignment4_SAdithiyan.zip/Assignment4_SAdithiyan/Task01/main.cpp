#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

class Staff {
protected:
    std::string name;
    int id;
public:
    Staff(std::string n, int i) : name(std::move(n)), id(i) {}
    virtual ~Staff() = default;
    virtual double pay() const = 0;
    virtual void print() const { std::cout << name << " (#" << id << ")"; }
};
class Professor : public Staff {
    double basic, research;
public:
    Professor(std::string n,int i,double b,double r):Staff(std::move(n),i),basic(b),research(r){}
    double pay() const override { return basic * 1.42 + research; }
};
class LabAssistant : public Staff {
    double basic;
public:
    LabAssistant(std::string n,int i,double b):Staff(std::move(n),i),basic(b){}
    double pay() const override { return basic * 1.42; }
};
class GuestFaculty : public Staff {
    double hours, rate;
public:
    GuestFaculty(std::string n,int i,double h,double r):Staff(std::move(n),i),hours(h),rate(r){}
    double pay() const override { return hours * rate; }
};
int main(){
    std::vector<std::unique_ptr<Staff>> payroll;
    payroll.push_back(std::make_unique<Professor>("Meera",101,50000,8000));
    payroll.push_back(std::make_unique<LabAssistant>("Ravi",102,30000));
    payroll.push_back(std::make_unique<GuestFaculty>("Kiran",103,20,1500));
    std::cout<<std::fixed<<std::setprecision(2);
    for(const auto& s:payroll){s->print();std::cout<<" pay="<<s->pay()<<'\n';}
}
