#include <iostream>
#include <string>
struct Person { std::string name; int id; Person(std::string n="",int i=0):name(std::move(n)),id(i){std::cout<<"Person ";} };
struct Student : virtual Person { std::string programme; double cgpa; Student(std::string n,int i,std::string p,double c):Person(n,i),programme(std::move(p)),cgpa(c){std::cout<<"Student ";} };
struct Staff : virtual Person { std::string department; double salary; Staff(std::string n,int i,std::string d,double s):Person(n,i),department(std::move(d)),salary(s){std::cout<<"Staff ";} };
struct TeachingAssistant : Student, Staff {
    TeachingAssistant(std::string n,int i,std::string p,double c,std::string d,double s)
    : Person(n,i), Student(n,i,p,c), Staff(n,i,d,s) { std::cout<<"TA "; }
};
struct ResearchScholar : Student { double fellowship; ResearchScholar(std::string n,int i,std::string p,double c,double f):Person(n,i),Student(n,i,p,c),fellowship(f){} };
int main(){TeachingAssistant ta("Anu",1,"CSE",8.7,"AI",25000);std::cout<<"\n"<<ta.name<<" "<<ta.id<<"\n";}
